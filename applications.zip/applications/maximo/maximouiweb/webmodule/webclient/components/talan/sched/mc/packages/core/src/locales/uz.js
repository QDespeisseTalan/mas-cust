
export default {
  code: "uz",
  buttonText: {
    month: "Oy",
    week: "Xafta",
    day: "Kun",
    list: "Kun tartibi"
  },
  allDayText: "Kun bo'yi",
  eventLimitText: function(n) {
    return "+ yana " + n;
  },
  noEventsMessage: "Ko'rsatish uchun voqealar yo'q"
}
