import { Hit } from './hit'

export type EventResizeJoinTransforms = (hit0: Hit, hit1: Hit) => false | object
