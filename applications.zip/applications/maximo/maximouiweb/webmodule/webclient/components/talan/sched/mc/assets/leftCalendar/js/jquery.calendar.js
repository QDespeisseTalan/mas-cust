/*
* jQuery-Calendar Plugin v1.1.1
*
* 2018 (c) Sebastian Knopf
* This software is licensed under the MIT license!
* View LICENSE.md for more information
*/
(function ($) {
	
	$.fn.calendar = function (opts) {
		var options = $.extend({
			color: '#325c80',//'#325c80',
			months: ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'],
			days: ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'],
			indice:0,
			with_button:0,
			onSelect: function (event) {}
		}, $.fn.calendar.defaults, opts);
		
		return this.each(function () {
			var currentYear, currentMonth , currentDay, currentCalendar;
			
			initCalendar($(this), options);
		});
	};
	
	
	function initCalendar(wrapper, options) {
		var color = options.color; 
		
		wrapper.addClass('calendar').empty();
		
		var header = $('<header>').appendTo(wrapper);
		header.addClass('calendar-header');
		header.css({
			background: color,
			color: createContrast(color)
		});
		if (options.with_button ==1)
		{
		var buttonLeft = $('<span>').appendTo(header);
		buttonLeft.addClass('button').addClass('left');
		//buttonLeft.html(' &lang; ');
		//buttonLeft.html('<i class="fa fa-arrow-left"></i>')
		buttonLeft.html('<img src="images/svg_icon/arrowLeft.svg" style="margin-top:-2px" width="20px">')
		buttonLeft.bind('click', function () { currentCalendar = $(this).parents('.calendar'); selectMonth(false, options); });
		buttonLeft.bind('mouseover', function () { $(this).css('background', createAccent(color, -20)); });
		buttonLeft.bind('mouseout', function () { $(this).css('background', color); });
		}
		var headerLabel = $('<span>').appendTo(header);
		headerLabel.addClass('header-label')
		headerLabel.html(' Month Year ');
		headerLabel.bind('click', function () { 
			currentCalendar =$('#pnlEventCalendar_x')//$(this).parents('.calendar');// $('#pnlEventCalendar_x')
			selectMonth(null, options, new Date().getMonth()+options.indice, new Date().getFullYear());
			//selectMonth(null, options, currentMonth, currentYear);

			//let currentDay = new Date().getDate();
		//	triggerSelectEvent(options.onSelect);
		
		});
		
		if (options.with_button ==1)
		{
		var buttonRight = $('<span>').appendTo(header);
		buttonRight.addClass('button').addClass('right');
		//buttonRight.html(' &rang; ');
		//buttonRight.html('<i class="fa fa-arrow-right"></i>')
		buttonRight.html('<img src="images/svg_icon/arrowRight.svg" style="margin-top:-2px" width="20px">')
		buttonRight.bind('click', function () 
		{ 			currentCalendar = $(this).parents('.calendar'); 
		//HHA.console.log('click right')
			selectMonth(true, options); 

		});
		buttonRight.bind('mouseover', function () { $(this).css('background', createAccent(color, -20)); });
		buttonRight.bind('mouseout', function () { $(this).css('background', color); });
	}
		var dayNames = $('<table>').appendTo(wrapper);
		dayNames.append('<thead><th>' + options.days.join('</th><th>') + '</th></thead>');
		dayNames.css({
			width: '100%'
		});
		
		var calendarFrame = $('<div>').appendTo(wrapper);
		calendarFrame.addClass('calendar-frame');
		
		headerLabel.click();
		headerLabel.unbind('click')
	}
	
	function selectMonth(next, options, month, year) {
		//var tmp_1 = $('#pnlEventCalendar_6').find('.header-label').text().trim().split(' '), tmpYear = parseInt(tmp[1], 10);
		var tmp = currentCalendar.find('.header-label').text().trim().split(' '), tmpYear = parseInt(tmp[1], 10);
		var tmp_2 = $( '#pnlEventCalendar_2' ).find('.header-label').text().trim().split(' '), tmpYear = parseInt(tmp[1], 10);
		var tmp_3 = $( '#pnlEventCalendar_3' ).find('.header-label').text().trim().split(' '), tmpYear = parseInt(tmp[1], 10);
		var tmp_4 = $( '#pnlEventCalendar_4' ).find('.header-label').text().trim().split(' '), tmpYear = parseInt(tmp[1], 10);
		var tmp_5 = $( '#pnlEventCalendar_5' ).find('.header-label').text().trim().split(' '), tmpYear = parseInt(tmp[1], 10);
		var tmp_6 = $( '#pnlEventCalendar_6' ).find('.header-label').text().trim().split(' '), tmpYear = parseInt(tmp[1], 10);
		//HHA.console.log('selectMonth')
		//HHA.console.log('tmp= ' +tmp)
		////HHA.console.log('tmp_6= '+tmp_6)
		//HHA.console.log('currentCalendar= ' + 			$( "pnlEventCalendar_6" ).find( '#pnlEventCalendar_6' ))	
		//HHA.console.log('------------------------month= ' +month)
		if (month === 0){
			currentMonth = month;
		} else{
			currentMonth = month || ((next) ? ((tmp[0] === options.months[options.months.length - 1]) ? 0 : options.months.indexOf(tmp[0]) + 1) : ((tmp[0] === options.months[0]) ? 11 : options.months.indexOf(tmp[0]) - 1));
		}
		
		currentYear = year || ((next && currentMonth === 0) ? tmpYear + 1 : (!next && currentMonth === 11) ? tmpYear - 1 : tmpYear);
		//HHA.console.log('currentMonth= ' +currentMonth+ ' currentMonth+5= '+(currentMonth+5)+' - currentYear= '+currentYear)
		var calendar = createCalendar(currentMonth, currentYear, options), frame = calendar.frame();
	/*	var calendar_2 = createCalendar(currentMonth+1, currentYear, options), frame_2 = calendar_2.frame();
		var calendar_3 = createCalendar(currentMonth+2, currentYear, options), frame_3 = calendar_3.frame();
		var calendar_4 = createCalendar(currentMonth+3, currentYear, options), frame_4 = calendar_4.frame();
		var calendar_5 = createCalendar(currentMonth+4, currentYear, options), frame_5 = calendar_5.frame();
		*/
		var calendar_2 = createCalendar(currentMonth+1, currentYear, options), frame_2 = calendar_2.frame();
		var calendar_3 = createCalendar(currentMonth+2, currentYear, options), frame_3 = calendar_3.frame();
		var calendar_4 = createCalendar(currentMonth+3, currentYear, options), frame_4 = calendar_4.frame();
		var calendar_5 = createCalendar(currentMonth+4, currentYear, options), frame_5 = calendar_5.frame();
		var calendar_6 = createCalendar(currentMonth+5, currentYear, options), frame_6 = calendar_6.frame();
		var calendar_7 = createCalendar(currentMonth+6, currentYear, options), frame_7 = calendar_7.frame();
		if((currentMonth+5)>=12)
		{
		var calendar_6 = createCalendar(currentMonth-7, currentYear+1, options), frame_6 = calendar_6.frame();
		if((currentMonth+5)>=13)
		var calendar_5 = createCalendar(currentMonth-8, currentYear+1, options), frame_5 = calendar_5.frame();
		if((currentMonth+5)>=14)
		var calendar_4 = createCalendar(currentMonth-9, currentYear+1, options), frame_4 = calendar_4.frame();
		if((currentMonth+5)>=15)
		var calendar_3 = createCalendar(currentMonth-10, currentYear+1, options), frame_3 = calendar_3.frame();
		if((currentMonth+5)>=16)
		var calendar_2 = createCalendar(currentMonth-11, currentYear+1, options), frame_2 = calendar_2.frame();

	
	}
	
		 // POUR UN CALENDRIER
	
		// POUR UN CALENDRIER
		$( '#pnlEventCalendar_2' ).find('.calendar-frame').empty().append(frame_2);
		$( '#pnlEventCalendar_2' ).find('.header-label').text(calendar_2.label);
		
		// FIN POUR UN CALENDRIER
		// POUR UN CALENDRIER
		$( '#pnlEventCalendar_3' ).find('.calendar-frame').empty().append(frame_3);
		$( '#pnlEventCalendar_3' ).find('.header-label').text(calendar_3.label);
		// FIN POUR UN CALENDRIER
		// POUR UN CALENDRIER
		$( '#pnlEventCalendar_4' ).find('.calendar-frame').empty().append(frame_4);
		$( '#pnlEventCalendar_4' ).find('.header-label').text(calendar_4.label);
		// FIN POUR UN CALENDRIER
		// POUR UN CALENDRIER
		$( '#pnlEventCalendar_5' ).find('.calendar-frame').empty().append(frame_5);
		$( '#pnlEventCalendar_5' ).find('.header-label').text(calendar_5.label);
		// FIN POUR UN CALENDRIER
		$( '#pnlEventCalendar_6' ).find('.calendar-frame').empty().append(frame_6);
		$( '#pnlEventCalendar_6' ).find('.header-label').text(calendar_6.label);

		$( '#pnlEventCalendar_7' ).find('.calendar-frame').empty().append(frame_7);
		$( '#pnlEventCalendar_7' ).find('.header-label').text(calendar_7.label);
	
		currentCalendar.find('.calendar-frame').empty().append(frame);
		currentCalendar.find('.header-label').text(calendar.label);
		
		// FIN POUR UN CALENDRIER
		frame.on('click', 'td', function () {
			$('td').removeClass('marked');
			$(this).addClass('marked');
		/*	$( '#pnlEventCalendar_x' ).addClass('selected');*/
			
			currentDay = $(this).text();
			triggerSelectEvent(options.onSelect,0);
		});
		frame_2.on('click', 'td', function () {
			$('td').removeClass('marked');
			$(this).addClass('marked');
			//$( '#pnlEventCalendar_6' ).addClass('selected');
			
			currentDay = $( this).text();
			triggerSelectEvent(options.onSelect, 1);
		});
		frame_3.on('click', 'td', function () {
			$('td').removeClass('marked');
			$(this).addClass('marked');
			//$( '#pnlEventCalendar_6' ).addClass('selected');
			
			currentDay = $( this).text();
			triggerSelectEvent(options.onSelect, 2);
		});
		frame_4.on('click', 'td', function () {
			$('td').removeClass('marked');
			$(this).addClass('marked');
			//$( '#pnlEventCalendar_6' ).addClass('selected');
			
			currentDay = $( this).text();
			triggerSelectEvent(options.onSelect, 3);
		});
		frame_5.on('click', 'td', function () {
			$('td').removeClass('marked');
			$(this).addClass('marked');
			//$( '#pnlEventCalendar_6' ).addClass('selected');
			
			currentDay = $( this).text();
			triggerSelectEvent(options.onSelect, 4);
		});
		frame_6.on('click', 'td', function () {
			$('td').removeClass('marked');
			$(this).addClass('marked');
			//$( '#pnlEventCalendar_6' ).addClass('selected');
			
			currentDay = $( this).text();
			triggerSelectEvent(options.onSelect, 5);

		});
		frame_7.on('click', 'td', function () {
			$('td').removeClass('marked');
			$(this).addClass('marked');
			//$( '#pnlEventCalendar_6' ).addClass('selected');
			
			currentDay = $( this).text();
			triggerSelectEvent(options.onSelect, 6);

		});
		
		//selectMonth(false, options, new Date().getMonth(), new Date().getFullYear())
	}	
	
	function createCalendar(month, year, options) {
		var currentDay = 1, daysLeft = true,
		startDay = new Date(year, month, currentDay).getDay() - 1,
		lastDays = [31, (((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31], 
		calendar = [];
		
		var i = 0;
		while(daysLeft) {
			calendar[i] = [];
			
			for(var d = 0; d < 7; d++) {
				if(i == 0) {
					if(d == startDay) {
						calendar[i][d] = currentDay++;
						startDay++;
					} else if (startDay === -1) {
            					calendar[i][6] = currentDay++;
            					startDay++;
					}
				} else if(currentDay <= lastDays[month]) {
					calendar[i][d] = currentDay++;
				} else {
					calendar[i][d] = ''; 
					daysLeft = false;
				}
				
				if (currentDay > lastDays[month]) { 
					daysLeft = false; 
				} 
			}
			
			i++;
		}
		
		var frame = $('<table>').addClass('current');
		var frameBody = $('<tbody>').appendTo(frame);
		
		for(var j = 0; j < calendar.length; j++) {
			var frameRow = $('<tr>').appendTo(frameBody);
			
			$.each(calendar[j], function (index, item) {
				var frameItem = $('<td>').appendTo(frameRow);
				frameItem.text(item);
			});
		}
		
		$('td:empty', frame).addClass('disabled');
		// Color Current Day
		if(currentMonth === new Date().getMonth() && options.with_button==1 && currentYear==new Date().getFullYear()) { 
		
			$('td', frame).filter(function () { return $(this).text() === new Date().getDate().toString(); }).addClass('selected'); 
		
		} 
	
		return { frame: function () { return frame.clone() }, label: options.months[month] + ' ' + year };
	}
	
	function triggerSelectEvent(event, indice_calendrier) {
		var date = new Date(currentYear, (currentMonth+indice_calendrier), currentDay);
	/*	var year_s = new Date(currentYear, currentMonth, currentDay).getFullYear()
		var month_s = new Date(currentYear, currentMonth, currentDay).getMonth()
		var day_s = new Date(currentYear, currentMonth, currentDay).getDay()
		var date = new Date(year_s, month_s, day_s);*/
			
		var label = [];
		label[0] = (date.getDate() < 10) ? '0' + date.getDate() : date.getDate();
		label[1] = ((date.getMonth() + 1) < 10) ? '0' + (date.getMonth() + 1) : date.getMonth() + 1;
		label[2] = (date.getFullYear());

		if(event != undefined) {
			event({date: date, label: label.join('.')});
		}
	}
	
	function createContrast(color) {
		if(color.length < 5) {
			color += color.slice(1);
		}
		
		return (color.replace('#','0x')) > (0xffffff) ? '#222' : '#fff';
	}
	
	function createAccent(color, percent) {
		var num = parseInt(color.slice(1),16), amt = Math.round(2.55 * percent), R = (num >> 16) + amt, G = (num >> 8 & 0x00FF) + amt, B = (num & 0x0000FF) + amt;
		return '#' + (0x1000000 + (R < 255 ? R < 1 ? 0 : R : 255) * 0x10000 + (G < 255 ? G < 1 ? 0 : G : 255) * 0x100 + (B < 255 ? B < 1 ? 0 : B : 255)).toString(16).slice(1);
	}

}(jQuery));
