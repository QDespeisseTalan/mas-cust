


async function fetchMaximoRequest (url) {
  let response = await fetch(url, { mode: 'same-origin', credentials: 'same-origin' }); // Credentials pour firefox avant la version 61
  let data = await response.json();
 
        return data;
    }

      //////DEBUT ACTIONS///////////////////
      export const actions = {
        /** Action de chargement du format de l'application
        Appelée en premier pour déterminer si l'on charge les données
        **/
        async chargementOption ({commit}) {
          // if(IS_MAXIMO){
          //       // let L_OPT = await fetchMaximoRequest('sched_talan_OPTION.jsp');
          //       commit('mutationOption', OPTIONS);
          //
          //   } else {
                commit('mutationOption', OPTIONS);
                commit('mutationOptionTMP', OPTIONS_TMP);
           //}
        },
        async chargementTask ({ commit }) {
        if(IS_MAXIMO){
              let L_TAS = await fetchMaximoRequest('sched_talan_DATA.jsp');
              
              commit('mutationTask', L_TAS)
              // commit('mutationAssign', L_ASS)
          } else {
              commit('mutationTask', require('./dataSet/datatest.json'));
              
          }
        },
        /////////////test pour les labors//////////////////
        async chargementLabor({commit}){
          ////HHA.console.log('++++++++++++++++++++++++++++++++++++++++date_du_centre= '+date_du_centre+ ' typeof ='+typeof(new Date(date_du_centre))+ ' new Date(date_du_centre) ='+new Date(date_du_centre))
        
          if(IS_MAXIMO){
            
           
           // if(date_du_centre !== undefined || !isNaN(new Date(date_du_centre))) this.variable=new Date(date_du_centre).getTime(); else this.variable=new Date().getTime();
           
        //    //HHA.console.log('LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL date_du_centre (this.variable) ='+this.variable)
            let  L_LAB= await fetchMaximoRequest('sched_talan_Labor.jsp');//?center_date='+this.variable);
         
         //HHA.console.log('typeOf(L_LAB))= '+typeof(L_LAB));
       
            commit('mutationLabors', L_LAB)
          } else {
           
            commit('mutationLabors', require('./dataSet/labor.json'));
         //   //HHA.console.log(this.root.state.options.scroll.chart.timeCenter)
            ////HHA.console.log('----------FIL ELSE----------------------ici c"est chargementTask datatest')
          
          }
        },
        async chargementLabor_only({commit}, date_du_centre){
          ////HHA.console.log('++++++++++++++++++++++++++++++++++++++++date_du_centre= '+date_du_centre+ ' typeof ='+typeof(new Date(date_du_centre))+ ' new Date(date_du_centre) ='+new Date(date_du_centre))
        
          if(IS_MAXIMO){
            
            if(date_du_centre !== undefined || !isNaN(new Date(date_du_centre))) this.variable=new Date(date_du_centre).getTime(); else this.variable=new Date().getTime();
            // //HHA.console.log('ic dan l_lab , new date get time = '+(new Date(date_du_centre)).getTime()+ ' || le type = '+typeof(new Date(date_du_centre).getTime()))
            //HHA.console.log('XXXXXXXXXXXXXXXXXXXXXXXXXXXXX date_du_centre (this.variable) ='+this.variable)
            let  L_LAB_only= await fetchMaximoRequest('sched_talan_Labor_only.jsp?center_date='+this.variable);
           // let  L_LAB= await fetchMaximoRequest('sched_talan_Labor.jsp');
        // //HHA.console.log(this.l_lab)
            ////HHA.console.log('-----------------------------------------ici c"est chargementTask ')
            //HHA.console.log('typeof(L_LAB_only)=== '+typeof(L_LAB_only));
            for (let y in L_LAB_only){
              //HHA.console.log('l_lab to afficher ='+L_LAB_only[y].day)
            //HHA.console.log('l_lab to afficher LaborCode ='+L_LAB_only[y].LaborCode)
          }
            commit('mutationLabors', L_LAB_only)
          } else {
           
            commit('mutationLabors', require('./dataSet/labor.json'));
         
         //   //HHA.console.log(this.root.state.options.scroll.chart.timeCenter)
            ////HHA.console.log('----------FIL ELSE----------------------ici c"est chargementTask datatest')
          
          }
        },
        
      };
