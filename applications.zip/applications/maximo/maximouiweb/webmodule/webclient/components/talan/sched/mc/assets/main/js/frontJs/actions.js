// Global Variables
var laborFiltredList = []
var statusFiltredList = []
var corpmetierFiltredList = []
var assignmentFiltredList = []
var gammeFilteredList = []
var emplacementFiltredList = []
var actifFiltredList = []
var pkdebutFiltredList = []
var pkfinFiltredList = []
var whereClauseValue;
Array.prototype.remove = function () {
	var what, a = arguments, L = a.length, ax;
	while (L && this.length) {
		what = a[--L];
		while ((ax = this.indexOf(what)) !== -1) {
			this.splice(ax, 1);
		}
	}
	return this;
};

function buildWhereClause() {
	whereClauseValue = null;
	if (laborFiltredList.length !== 0) {
		whereClauseValue = "LABORCODE IN (";
		laborFiltredList.forEach(buildString);
		function buildString(value) {
			whereClauseValue = whereClauseValue + "'" + value + "',";
		}
		whereClauseValue = whereClauseValue.substring(0, whereClauseValue.length - 1) + ")";
	}
	//
	if (statusFiltredList.length !== 0) {
		if (whereClauseValue != null) {
			whereClauseValue = whereClauseValue + " AND STATUS IN (";
		}
		else
			whereClauseValue = "STATUS IN (";
		statusFiltredList.forEach(buildString);
		function buildString(value) {
			whereClauseValue = whereClauseValue + "'" + value + "',";
		}
		whereClauseValue = whereClauseValue.substring(0, whereClauseValue.length - 1) + ")";
	}
	//
	if (corpmetierFiltredList.length !== 0) {
		if (whereClauseValue != null) {
			whereClauseValue = whereClauseValue + " AND LABORCRAFT IN (";
		}
		else
			whereClauseValue = "LABORCRAFT IN (";
		corpmetierFiltredList.forEach(buildString);
		function buildString(value) {
			whereClauseValue = whereClauseValue + "'" + value + "',";
		}
		whereClauseValue = whereClauseValue.substring(0, whereClauseValue.length - 1) + ")";
	}
	//
	if (gammeFilteredList.length !== 0) {
		if (whereClauseValue != null) {
			whereClauseValue = whereClauseValue + " AND JPNUM IN ("
		}
		else
			whereClauseValue = "JPNUM IN ("
		gammeFilteredList.forEach(buildString);
		function buildString(value) {
			whereClauseValue = whereClauseValue + "'" + value + "',";
		}
		whereClauseValue = whereClauseValue.substring(0, whereClauseValue.length - 1) + ")";
	}
	//
	if (emplacementFiltredList.length !== 0) {
		if (whereClauseValue != null) {
			whereClauseValue = whereClauseValue + " AND LOCATION IN ("
		}
		else
			whereClauseValue = "LOCATION IN ("
		emplacementFiltredList.forEach(buildString);
		function buildString(value) {
			whereClauseValue = whereClauseValue + "'" + value + "',";
		}
		whereClauseValue = whereClauseValue.substring(0, whereClauseValue.length - 1) + ")";
	}
	//
	if (actifFiltredList.length !== 0) {
		if (whereClauseValue != null) {
			whereClauseValue = whereClauseValue + " AND ASSETNUM IN("
		}
		else
			whereClauseValue = "ASSETNUM IN ("
		actifFiltredList.forEach(buildString);
		function buildString(value) {
			whereClauseValue = whereClauseValue + "'" + value + "',";
		}
		whereClauseValue = whereClauseValue.substring(0, whereClauseValue.length - 1) + ")";
	}
	if (pkdebutFiltredList.length !== 0) {
		if (whereClauseValue != null) {
			whereClauseValue = whereClauseValue + " AND WOEQ5 IN("
		}
		else
			whereClauseValue = "WOEQ5 IN ("
			pkdebutFiltredList.forEach(buildString);
		function buildString(value) {
			whereClauseValue = whereClauseValue + "'" + value + "',";
		}
		whereClauseValue = whereClauseValue.substring(0, whereClauseValue.length - 1) + ")";
	}
	if (pkfinFiltredList.length !== 0) {
		if (whereClauseValue != null) {
			whereClauseValue = whereClauseValue + " AND WOEQ7 IN("
		}
		else
			whereClauseValue = "WOEQ7 IN ("
			pkfinFiltredList.forEach(buildString);
		function buildString(value) {
			whereClauseValue = whereClauseValue + "'" + value + "',";
		}
		whereClauseValue = whereClauseValue.substring(0, whereClauseValue.length - 1) + ")";
	}




	//
	console.log('whereClauseValue FINALE= ' + whereClauseValue)
}

async function fetchMaximoRequest(url) {
	let response = await fetch(url, { mode: 'same-origin', credentials: 'same-origin' }); // Credentials pour firefox avant la version 61
	let data = await response.json();

	return data;
}
function enable_full_screen() {
	return this.full_screen_

}
function disable_full_screen() {
	this.full_screen_ = false
	var iconFullScreen = document.getElementById('imageFullScreen')
	var imageLigneFullScreen = document.getElementById('imageLigneFullScreen')
	if (iconFullScreen.classList.contains('ScreenFilHovered')) {
		iconFullScreen.classList.remove('ScreenFilHovered');
		imageLigneFullScreen.classList.remove('LinedisplayInline');
	}
}
function enable_charge_employe() {
	return this.charge_employe

}
function enable_charge_intervention() {
	return this.charge_intervention

}
function total_full_screen() {
	console.log('full_screen_ ' + enable_full_screen())

	if (!enable_full_screen()) {

		document.getElementById("body_parent").requestFullscreen();
		this.full_screen_ = true
		console.log(' enable_full_screen full_screen_ ' + this.full_screen_)

	}
	else {
		document.exitFullscreen();
		this.full_screen_ = false
	}
	var iconFullScreen = document.getElementById('imageFullScreen')
	iconFullScreen.classList.toggle('ScreenFilHovered')
	var imageLigneFullScreen = document.getElementById('imageLigneFullScreen')
	imageLigneFullScreen.classList.toggle('LinedisplayInline')

}
function full_screen() {
	if (!enable_full_screen()) {

		closeNav_employe()
		closeNav_intervention()
		//document.style.marginLeft="0";
		document.getElementById("body").style.marginLeft = "0";
		document.getElementById("body").style.marginTop = "0";
		document.getElementById("calendar").style.marginLeft = "0";
		document.getElementById("calendar").style.marginTop = "0";
		document.getElementById("calendar").style.width = "100%";
		document.getElementById("calendar").style.height = "100%";
		this.full_screen_ = true
	}
	else {

		document.getElementById("body").style.marginLeft = "10%";
		document.getElementById("wrap").style.marginLeft = "0";
		document.getElementById("body").style.marginTop = "40px";
		openNav_employe()
		this.full_screen_ = false
		var taille_ = $(window).width() - document.getElementById("calendar").offsetWidth;
		document.getElementById("id_sidenav_employe").style.width = taille_ + "px";
	}

}
function lirejson_emp() {
	var div_employe = document.getElementById("id_sidenav_employe");
	var liste_employe = [];
	$.getJSON("dataSet/labor.json", function (data) {
		$.each(data, function (assLabor, personname) {
			var a_employe = document.createElement('a');
			a_employe.textContent = data[assLabor].personname + ' / ' + data[assLabor].LabCraft + ' / ' + data[assLabor].LabSkilllevel;
			a_employe.id = assLabor;
			a_employe.draggable = true;
			var progress_barr = document.createElement("div")
			progress_barr.setAttribute("class", "progress")
			progress_barr.setAttribute("style", "width:80%;")
			var progress_barr_bis = document.createElement("div")
			progress_barr_bis.setAttribute("class", "progress-bar progress-bar-striped active")
			progress_barr_bis.setAttribute("role", "progressbar")
			progress_barr_bis.setAttribute("aria-valuenow", "40")
			progress_barr_bis.setAttribute("aria-valuemin", "0")
			progress_barr_bis.setAttribute("aria-valuemax", "100")
			progress_barr_bis.setAttribute("style", "width:" + ((data[assLabor].laborCharge / data[assLabor].laborHours) * 100) + "%")
			progress_barr_bis.append(((data[assLabor].laborCharge / data[assLabor].laborHours) * 100) + "%")
			div_employe.appendChild(a_employe);
			progress_barr.appendChild(progress_barr_bis);
			div_employe.appendChild(progress_barr);
		}

		);

	});
}
function supprimer_filtre(cible, origin_filtre) {
	var div_filtre = document.getElementById(cible)
	while (div_filtre.firstChild) {
		div_filtre.removeChild(div_filtre.firstChild);
	}
	document.getElementById(origin_filtre).value = '';

}


//BCH cette fonction ajoute le filtre dans sa section avec une croix pour suppression si besoin
function filtre_categ(event, origin_filtre, cible) {
	var valeur_rec = document.getElementById(origin_filtre).value;
	//console.log('dans function filtre_categ= ' + event.keyCode)
	if (event.keyCode == 13 && valeur_rec !== '') {
		//add customization of the buildwhere clause and filling of the filtres
		filtre_categ_autocomplete_custom(event, origin_filtre, cible, valeur_rec);
		var _filtre = document.getElementById(cible)
		var un_filtre = document.createElement('h3')

		un_filtre.textContent = valeur_rec
		var button = document.createElement('button')
		button.textContent = 'X'
		button.className = 'small_button'
		un_filtre.id = valeur_rec
		button.style.float = 'right'
		button.set
		button.addEventListener('click', function () {

			document.getElementById(cible).removeChild(document.getElementById(valeur_rec))

			//consider the new filters introduced by BCH and empty the filters
			switch (cible) {
				case 'gamme_filtre':
					{
						gammeFilteredList.remove(valeur_rec);
						break;
					}
				case 'emplacement_filtre':
					{
						emplacementFiltredList.remove(valeur_rec);
						break;
					}
				case 'actif_filtre':
					{
						actifFiltredList.remove(valeur_rec);
						break;
					}
					case 'pkdebut_filtre':
					{
						pkdebutFiltredList.remove(valeur_rec);
						break;
					}
					case 'pkfin_filtre':
					{
						pkfinFiltredList.remove(valeur_rec);
						break;
					}
			}
			buildWhereClause();
			calendar.refetchEvents();
		})
		un_filtre.appendChild(button)
		_filtre.appendChild(un_filtre)
		document.getElementById(origin_filtre).value = '';
	}
}
// filtre direct depuis liste autocomplete qui remplit une variable globale avec les données des filtres
function filtre_categ_autocomplete(origin_filtre, cible, valeur) {
	switch (origin_filtre) {
		case 'filtre_employe': laborFiltredList.push(valeur); break;
		case 'filtre_statut': statusFiltredList.push(valeur); break;
		case 'filtre_corp_metier': corpmetierFiltredList.push(valeur); break;
		case 'filtre_intervention': assignmentFiltredList.push(valeur); break;
		case 'filtre_gamme': gammeFilteredList.push(valeur); break;
		case 'filtre_emplacement': emplacementFiltredList.push(valeur); break;
		case 'filtre_actif': actifFiltredList.push(valeur); break;
		case 'filtre_pkdebut': pkdebutFiltredList.push(valeur); break;
		case 'filtre_pkfin': pkfinFiltredList.push(valeur); break;
	}
	
	buildWhereClause();
	calendar.refetchEvents();
	{
		var _filtre = document.getElementById(cible)
		var un_filtre = document.createElement('h3')

		un_filtre.textContent = valeur
		var button = document.createElement('button')
		button.textContent = 'X'
		button.className = 'small_button'
		un_filtre.id = valeur
		button.style.float = 'right'
		button.addEventListener('click', function () {
			document.getElementById(cible).removeChild(document.getElementById(valeur))
			var xFilterOption = document.createElement('option');
			if (cible == 'employe_filtre') {
				var labor = getLaborByCode(valeur);
				xFilterOption.textContent = labor.LABORCODE + ' - ' + labor.DISPLAYNAME;
				xFilterOption.setAttribute('value', labor.LABORCODE);

			}
			else {
				xFilterOption.textContent = valeur
				xFilterOption.setAttribute('value', valeur);
			}
			document.getElementById(origin_filtre).appendChild(xFilterOption);
			switch (cible) {
				case 'employe_filtre':
					{
						laborFiltredList.remove(valeur);
						break;
					}
				case 'statut_filtre':
					{
						statusFiltredList.remove(valeur);
						break;
					}
				case 'gamme_filtre':
					{
						gammeFilteredList.remove(valeur);
						break;
					}
				case 'corp_metier_filtre':
					{
						corpmetierFiltredList.remove(valeur);
						break;
					}
				case 'intervention_filtre':
					{
						assignmentFiltredList.remove(valeur);
						break;
					}
				case 'emplacement_filtre':
					{
						emplacementFiltredList.remove(valeur);
						break;
					}
				case 'actif_filtre':
					{
						actifFiltredList.remove(valeur);
						break;
					}
					case 'pkdebut_filtre':
					{
						pkdebutFiltredList.remove(valeur);
						break;
					}
					case 'pkfin_filtre':
					{
						pkfinFiltredList.remove(valeur);
						break;
					}
			}
			buildWhereClause();
			calendar.refetchEvents();
		})
		un_filtre.appendChild(button)
		_filtre.appendChild(un_filtre)
		document.getElementById(origin_filtre).value = '';
	}
}

//Custom de la fonction filtre categ autocomplete pour gérer les champs gamme , actif, pk debut ...

// filtre direct depuis liste autocomplete qui remplit une variable globale avec les données des filtres
function filtre_categ_autocomplete_custom(event, origin_filtre, cible, valeur) {

	console.log('ici dans filtre categ autocomplete custom');
	//console.log('dans function filtre_categ= ' + event.keyCode)
	if (event.keyCode === 13) {
		console.log('ici dans filtre categ autocomplete custom');
		switch (origin_filtre) {

			case 'filtre_gamme': gammeFilteredList.push(valeur); break;
			case 'filtre_emplacement': emplacementFiltredList.push(valeur); break;
			case 'filtre_actif': actifFiltredList.push(valeur); break;
			case 'filtre_pkdebut': pkdebutFiltredList.push(valeur); break;
			case 'filtre_pkfin': pkfinFiltredList.push(valeur); break;
		}

		buildWhereClause();
		calendar.refetchEvents();
	}
}

function optionsGenerator(valeur, fitreOrigin) {
	// LISTE SELECTION FILTRE 'filtre_intervention'
	var xFilterOptions = document.getElementById(fitreOrigin)
	var xFilterOption = document.createElement('option')
	xFilterOption.textContent = valeur;
	xFilterOption.setAttribute('value', valeur)
	xFilterOptions.appendChild(xFilterOption);
}
// fin filtre direct depuis liste autocomplete
function close_menu() {
	var div_intervention = document.getElementById("id_sidenav_menu");
	document.getElementById('menu_external_function').style.visibility = 'collapse'
	document.getElementById('liste_des_interventions').style.display = 'none'
	document.getElementById('liste_des_employes').style.display = 'none'
	document.getElementById('filtre_employe').style.visibility = 'collapse'
	document.getElementById('filtre_statut').style.visibility = 'collapse'
	document.getElementById('filtre_emplacement').style.visibility = 'collapse'	
	document.getElementById('filtre_actif').style.visibility = 'collapse'
	document.getElementById('filtre_pkdebut').style.visibility = 'collapse'
	document.getElementById('filtre_pkfin').style.visibility = 'collapse'
	document.getElementById('filtre_corp_metier').style.visibility = 'collapse'
	//document.getElementById('filtre_intervention').style.visibility = 'collapse'
	document.getElementById('div_filtre').style.visibility = 'collapse'
	document.getElementById('tabs_sidebar').style.visibility = 'collapse'
	document.getElementById("wrap").style.marginLeft = '0';
	document.getElementById("wrap").style.width = '100.0%';
	document.getElementById("menu1").style.visibility = 'collapse'
	document.getElementById("menu2").style.visibility = 'collapse'
	document.getElementById("menu3").style.visibility = 'collapse'


	div_intervention.style.width = '1%';
}
function open_menu() {
	var div_intervention = document.getElementById("id_sidenav_menu");
	div_intervention.style.width = '20.4%';

	document.getElementById('menu_external_function').style.visibility = 'visible'
	document.getElementById('filtre_employe').style.visibility = 'visible'
	document.getElementById('filtre_statut').style.visibility = 'visible'
	document.getElementById('filtre_emplacement').style.visibility = 'visible'
	document.getElementById('filtre_actif').style.visibility = 'visible'
	document.getElementById('filtre_pkdebut').style.visibility = 'visible'
	document.getElementById('filtre_pkfin').style.visibility = 'visible'
	document.getElementById('filtre_corp_metier').style.visibility = 'visible'
	//document.getElementById('filtre_intervention').style.visibility = 'visible'
	document.getElementById('div_filtre').style.visibility = 'visible'
	document.getElementById('tabs_sidebar').style.visibility = 'visible'
	document.getElementById("wrap").style.marginLeft = '9.6%';
	document.getElementById("wrap").style.width = '90.4%';
	document.getElementById("liste_des_interventions").style.display = 'block'
	document.getElementById('liste_des_employes').style.display = 'block'
	document.getElementById("menu1").style.visibility = 'visible'
	document.getElementById("menu2").style.visibility = 'visible'
	document.getElementById("menu3").style.visibility = 'visible'

}
function open_div_intervention() {
	console.log('dans open div intervention')
	var div_intervention_ = document.getElementById("id_intervention_");
	div_intervention_.style.width = '18%'
	var div_intervention_ = document.getElementById("id_sidenav_menu");
	div_intervention_.style.width = '3%'
	var div_intervention = document.getElementById("id_sidenav_menu");

	document.getElementById('menu_external_function').style.visibility = 'hidden'
	document.getElementById('filtre_employe').style.visibility = 'hidden'
	document.getElementById('filtre_statut').style.visibility = 'hidden'
	document.getElementById('filtre_corp_metier').style.visibility = 'hidden'
	//document.getElementById('filtre_intervention').style.visibility = 'hidden'
	document.getElementById('div_filtre').style.visibility = 'hidden'
	document.getElementById('filtre_name').style.visibility = 'hidden'
	document.getElementById("liste_des_interventions").style.visibility = 'hidden'


}
function open_div_employe() {
	console.log('dans open div id_employe_')
	var div_intervention_ = document.getElementById("id_employe_");
	div_intervention_.style.width = '12%'

}
async function lirejson_interventions() {

	var div_intervention = document.getElementById("liste_des_interventions");
	var a_inter = document.createElement('h1');
	a_inter.textContent = 'Helmi';
	a_inter.id = 'Helmim';
	a_inter.draggable = true;
	div_intervention.appendChild(a_inter);

	var compteur = 0

	console.log('Dans lirejson_interventions ')
	let data = await fetchMaximoRequest('maximoSources/jsp/PLANIF_WO_DATA.jsp')
	$.each(data, function (inter_num) {
		var a_inter = document.createElement('h1');
		a_inter.textContent = data[inter_num].WONUM + ' - ' + data[inter_num].DESCRIPTION + ' - ' + data[inter_num].STATUS;
		a_inter.id = inter_num;
		a_inter.draggable = true;
		compteur++
		div_intervention.appendChild(a_inter);
	});

	document.getElementById('meun_intervention').textContent = 'Interventions (' + compteur + ')';
}
async function getAllAssignments() {
	data = await fetchMaximoRequest('maximoSources/jsp/ASSIGNMENTS_DATA.jsp');
	return data;
}
async function populateAssignments() {

	let data = await fetchMaximoRequest('maximoSources/jsp/ASSIGNMENTS_DATA.jsp')

	$.each(data, function (inter_num) {

		var s_date // Start Date Event
		var e_date  // End Date Event
		// START DATE
		if (data[inter_num].STARTDATE != undefined)
			s_date = data[inter_num].STARTDATE;
		else
			s_date = data[inter_num].SCHEDULEDATE;

		var start_date = new Date(s_date)
		var start_date_d = start_date.getDate();
		var start_date_m = start_date.getMonth();
		var start_date_y = start_date.getFullYear();
		var start_date_h = start_date.getHours()
		var start_date_mm = start_date.getMinutes();
		// END DATE
		if (data[inter_num].FINISHDATE != undefined) {
			e_date = data[inter_num].FINISHDATE;
			var end_date = new Date(e_date)
		}

		else {
			var minutes = (parseInt(data[inter_num].LABORHRS.split(':')[0]) * 60) + parseInt(data[inter_num].LABORHRS.split(':')[1])
			var end_date = new Date(start_date)

			end_date.setMinutes(end_date.getMinutes() + minutes);
		}


		var end_date_d = end_date.getDate();
		var end_date_m = end_date.getMonth();
		var end_date_y = end_date.getFullYear();
		var end_date_h = end_date.getHours()
		var end_date_mm = end_date.getMinutes();
		// LABOR / EN CHARGE
		var en_charge = ' '

		if (data[inter_num].AMCREW !== undefined && data[inter_num].AMCREW !== '')
			en_charge = ' (' + data[inter_num].AMCREW + ')'
		else
			if (data[inter_num].LABORCODE !== undefined)
				en_charge = ' (' + data[inter_num].LABORCODE + ')'
	});
}

function openNav_intervention() {
	// HHA- Charge des intervention uniquement une fois 
	if (!enable_charge_intervention()) {
		lirejson_interventions();
		this.charge_intervention = true
	}

	document.getElementById("id_sidenav_employe").style.width = "0";
	document.getElementById("id_sidenav_intervention").style.width = "400px";

}


function openNav() {
	// HHA - Charge des employes uniquement une fois 
	var taille = $(window).width() - document.getElementById("calendar").offsetWidth;
	if (this.full_screen_)
		document.getElementById("id_sidenav_employe").style.width = "250px";

	else
		document.getElementById("id_sidenav_employe").style.width = taille + "px";
}

function openNav_employe() {
	// HHA - Charge des employes uniquement une fois 
	if (!enable_charge_employe()) {
		lirejson_emp();
		this.charge_employe = true
	}


	document.getElementById("id_sidenav_intervention").style.width = "0";
	//HHA.console.log('zoom ratio= '+ window.devicePixelRatio)
	var taille = $(window).width() - document.getElementById("calendar").offsetWidth;
	if (this.full_screen_)
		document.getElementById("id_sidenav_employe").style.width = "250px";

	else
		document.getElementById("id_sidenav_employe").style.width = taille + "px";
}

function closeNav_employe() {

	document.getElementById("id_sidenav_employe").style.width = "0";
}
function closeNav_intervention() {
	document.getElementById("id_sidenav_intervention").style.width = "0";
}

function montre(text) {
	{
		document.getElementById("curseur").style.visibility = "visible"; // Si il est cacher (la verif n'est qu'une securité) on le rend visible.
		document.getElementById("curseur").innerHTML = text; // on copie notre texte dans l'élément html

	}
}
/// AUTOCOMPLETE
function autocomplete(inp, arr, origin_filtre, cible) {
	/*the autocomplete function takes two arguments,
	the text field element and an array of possible autocompleted values:*/
	var currentFocus;
	/*execute a function when someone writes in the text field:*/
	inp.addEventListener("input", function (e) {
		var a, b, i, val = this.value;
		/*close any already open lists of autocompleted values*/
		closeAllLists();
		if (!val) { return false; }
		currentFocus = -1;
		/*create a DIV element that will contain the items (values):*/
		a = document.createElement("DIV");
		a.setAttribute("id", this.id + "autocomplete-list");
		a.setAttribute("class", "autocomplete-items");
		/*append the DIV element as a child of the autocomplete container:*/
		this.parentNode.appendChild(a);

	});
	/*execute a function presses a key on the keyboard:*/
	inp.addEventListener("keydown", function (e) {
		var x = document.getElementById(this.id + "autocomplete-list");
		if (x) x = x.getElementsByTagName("div");
		if (e.keyCode == 40) {
			/*If the arrow DOWN key is pressed,
			increase the currentFocus variable:*/
			currentFocus++;
			/*and and make the current item more visible:*/
			addActive(x);
		} else if (e.keyCode == 38) { //up
			/*If the arrow UP key is pressed,
			decrease the currentFocus variable:*/
			currentFocus--;
			/*and and make the current item more visible:*/
			addActive(x);
		} else if (e.keyCode == 13) {
			/** POUR PASSER AU DIF DES FILTRES */
			var valeur_rec = document.getElementById(origin_filtre).value;
			var _filtre = document.getElementById(cible)
			var un_filtre = document.createElement('h3')
			un_filtre.textContent = valeur_rec
			var button = document.createElement('button')
			button.textContent = 'X'
			button.className = 'small_button'
			un_filtre.id = valeur_rec
			button.style.float = 'right'
			button.set
			button.addEventListener('click', function () {
				document.getElementById(cible).removeChild(document.getElementById(valeur_rec))
			})
			un_filtre.appendChild(button)
			_filtre.appendChild(un_filtre)
			document.getElementById(origin_filtre).value = '';
			/*If the ENTER key is pressed, prevent the form from being submitted,*/
			e.preventDefault();
			if (currentFocus > -1) {
				/*and simulate a click on the "active" item:*/
				if (x) x[currentFocus].click();
			}
		}
	});
	function addActive(x) {
		/*a function to classify an item as "active":*/
		if (!x) return false;
		/*start by removing the "active" class on all items:*/
		removeActive(x);
		if (currentFocus >= x.length) currentFocus = 0;
		if (currentFocus < 0) currentFocus = (x.length - 1);
		/*add class "autocomplete-active":*/
		x[currentFocus].classList.add("autocomplete-active");
	}
	function removeActive(x) {
		/*a function to remove the "active" class from all autocomplete items:*/
		for (var i = 0; i < x.length; i++) {
			x[i].classList.remove("autocomplete-active");
		}
	}
	function closeAllLists(elmnt) {
		/*close all autocomplete lists in the document,
		except the one passed as an argument:*/
		var x = document.getElementsByClassName("autocomplete-items");
		for (var i = 0; i < x.length; i++) {
			if (elmnt != x[i] && elmnt != inp) {
				x[i].parentNode.removeChild(x[i]);
			}
		}
	}
	/*execute a function when someone clicks in the document:*/
	document.addEventListener("click", function (e) {
		closeAllLists(e.target);
	});
}
var statut_ = ['COMP', 'WAPP', 'CLOSED'];
var corps_metier_ = ['ELEC', 'MEC'];
var intervention_ = ['1022', '1060'];
function gestion_sidebar() {
	var div_intervention = document.getElementById("id_sidenav_menu").style.width
	var button_open_field = document.getElementById("button_open_field")

	if (div_intervention > '14%') {
		close_menu()
		button_open_field.textContent = '>'
	}
	else {
		open_menu()
		button_open_field.textContent = '<'
	}

}


