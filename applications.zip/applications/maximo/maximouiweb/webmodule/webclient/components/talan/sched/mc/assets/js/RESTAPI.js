function requestData() {
    var request = new XMLHttpRequest();
    // set your hostname here
    var host = "http://mx7vm";
    // set your REST URI here
    var uri = "/oslc/script/HHASCRIPT";
    // your query parameters
        var parameters = "site=BEDFORD";
    // defines which function is called when state change
    request.onreadystatechange = state_change;
//http://46.105.47.97:21081/maximo/oslc/os/PLANIF_ASSIGN/134600/assignment?_lid=maxadmin&_lpwd=maxadmin&oslc.select=assignmentid&oslc.pageSize=1&oslc.orderBy=-assignmentid
    request.open("GET", "http://mx7vm/maximo/oslc/script/HHASCRIPT?" + parameters, true);
    // send authorization credentials, base64 encoded for "maxadmin:maxadmin"
    //request.setRequestHeader("Authorization", "Basic " + "bWF4YWRtaW46bWF4YWRtaW4=");

    request.send();
     
    function state_change() {
      if (request.readyState == 4) { // 4 = "loaded"
        if (request.status == 200) { // 200 = OK
            // get the XML root element
          //  var root = JSON.parse(request);// request.responseXML;//.firstChild;
            // get all the tags named DISPLAYNAME
            //var displayNameTags = root.getElementsByTagName("wocount");
            // gets the first displayName tag value
            var displayName = JSON.parse(request.responseText) ;//displayNameTags[0].nodeValue;
            alert('displayNameTags TEST= '+displayName.wocount);
          }
          else {
            alert(request.status + " - " + request.statusText);
        }
      }
    }
  }