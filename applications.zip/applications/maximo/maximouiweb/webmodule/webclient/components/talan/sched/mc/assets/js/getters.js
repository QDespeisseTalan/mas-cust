// Global Variables
var jsonWorkorderList = {workorders : []};
var jsonWorkorderList_ = {workorders : []};
var jsonLaborList = {labors : []};

// Get the json aboject based on maximum int value for tag
function getLastObject(jsonArray, elementTagName) {
    const max = jsonArray.reduce(function(prev, current) {
        return (parseInt(prev[elementTagName]) > parseInt(current[elementTagName])) ? prev : current
    });
    return max;
}

// Get the json aboject based on exact int value for tag
function getObject(jsonArray, elementTagName,elementValue) {
    var max = jsonArray.find(function(obj){
        return obj[elementTagName]===elementValue;
    });
    return max;
}
// Get Workorder by workorderid
function getWorkorderById(id)
{
	return jsonWorkorderList.workorders.find(function (wo) {
		return wo.workorderID===parseInt(id);
	});
}
function getWorkordersById(idGroup, listework)
{
	var liste =[]
	 jsonWorkorderList_.workorders.find(function (wo) {
		// console.log(wo.WOGROUP+' - '+typeof wo.WOGROUP+' / '+idGroup+' - '+ typeof idGroup)
		if( parseInt(wo.WOGROUP)===idGroup)
		liste.push(wo)
	});
	console.log(liste)
	return liste
}
// Get labor by laborcode
function getLaborByCode(code)
{
	return jsonLaborList.labors.find(function (labor) {
		return labor.LABORCODE===code;
	});
}
// Get labors by orgid
function getLaborsByOrgid(org)
{
	return jsonLaborList.labors.filter(function (labor) {
		return labor.ORGID===org;
	});
}
// Get labor by orgid and worksite
function getLaborsByOrgidWrkSite(org,wrksite)
{
	return jsonLaborList.labors.find(function (labor) {
		return labor.ORGID===org && labor.ORGID.WORKSITE===wrksite;
	});
}
// Get event background color based on workorder systemstatus
function getColorByID(id){
	// TODO get colors from parameters
	console.log("Given id "+id);
	console.log("WO count "+jsonWorkorderList.workorders.length)
	var systemStatus = jsonWorkorderList.workorders.find(wo => wo.workorderID===id).workorderSystemStatus;
	return getColorByStatus(systemStatus);
	}

// Get application context path
function getBaseURL() {
	var path = window.location.pathname
		var idx = path.indexOf( "/webclient" );
		path = path.substring( 0, idx );
		var port = window.location.port;
		var url = window.location.protocol+"//"+window.location.hostname;
		if (typeof port !== "undefined" && port !== "" && port !== null)
			url = url+":"+window.location.port+path;
		else
			url = url+path;
		console.log("URL:"+url);
		return url
}

// Get Time from minutes
function getTimeFromMins(mins) {
    // do not include the first validation check if you want, for example,
    // getTimeFromMins(1530) to equal getTimeFromMins(90) (i.e. mins rollover)
    if (mins >= 24 * 60 || mins < 0) {
        throw new RangeError("Valid input should be greater than or equal to 0 and less than 1440.");
    }
    var h = mins / 60 | 0,
        m = mins % 60 | 0;
    return moment.utc().hours(h).minutes(m).format("HH:mm");
}

// Get minutes from float hours
function getMinsFromHours(hours) {

    return  Math.floor(hours) * 60 + (hours - (Math.floor(hours))) * 60;
}
// get and init labor list
async function getLaborList(){
  let data = await fetchMaximoRequest('./JSP/LABORS_DATA.jsp?talPlanifId='+planifId);
  var div_employe = document.getElementById ("liste_des_employes");
  var laborFilterOptions = document.getElementById('filtre_employe');

  data.map(function (employe){
	jsonLaborList.labors.push(employe);
	var p_employe = document.createElement('p');
	p_employe.innerHTML=employe.LABORCODE +' - '+employe.DISPLAYNAME+'<br>'+employe.CALNUM + ' - '+employe.SHIFTNUM+'<br>'+employe.CRAFT
	p_employe.id=employe.LABORID;
	p_employe.className='liste_employe';
	p_employe.draggable=true;
	// APPEND
	div_employe.appendChild(p_employe);
	var trait = document.createElement('hr');
	trait.className='trait_menu_employe';
	div_employe.appendChild(trait);
	optionsGenerator(employe.CRAFT,'filtre_corp_metier')
	var laborFilterOption = document.createElement('option');
	laborFilterOption.textContent=employe.LABORCODE +' - '+employe.DISPLAYNAME;
	laborFilterOption.setAttribute('value',employe.LABORCODE);
	laborFilterOptions.appendChild(laborFilterOption);
  });
}
// get and init workorder list
async function getWorkorderList(){
  let data = await fetchMaximoRequest('./JSP/WORKORDERS_DATA.jsp?talPlanifId='+planifId);
	var div_intervention = document.getElementById ("liste_des_interventions");
	data.map(function (workorder){
		// Add the workorder object to the list
		
		jsonWorkorderList.workorders.push(workorder);
		var notAssigned = false
		if (parseInt(workorder.woTotalAssignments) === 0 || parseInt(workorder.woNonAssignedAssignments) > 0 )
		{
			notAssigned = true;
		}
		if (workorder.istask==0 && notAssigned){
		var p_intervention = document.createElement('p');
		p_intervention.innerHTML='<strong>'+workorder.WONUM+': '+'</strong>'+workorder.workorderDescription+'<br>';
		if (typeof workorder.woTargStartDate !== undefined) {
			p_intervention.innerHTML +='<strong>'+'Début objectif: '+'</strong>'+workorder.woTargStartDate;
		}
		p_intervention.innerHTML += '<br> <strong>'+'Statut: '+'</strong>'+workorder.workorderStatus;

		p_intervention.id=workorder.workorderID;

		p_intervention.className='liste_intervention';
		p_intervention.draggable=true;
				 
		// APPEND
		div_intervention.appendChild(p_intervention);
		var trait = document.createElement('hr');
		trait.className='trait_menu_intervention';
		div_intervention.appendChild(trait);	
	}	
	});
 }
 // get businesshours
 async function getBusinessHours(cal){
	let data = await fetchMaximoRequest('./JSP/businessHours.jsp?talPlanifId='+planifId);
	var businessHours = {
			startTime : data.startTime,
			endTime : data.endTime,
			daysOfWeek : data.daysOFWeek
		};
	cal.setOption('businessHours', businessHours);
   }
 function getWorkorderAttributeValue(workorderID,attributeName)
 {
	 var workorderElement = $('#'+workorderID).data(attributeName);
 }
 
function getColorByStatus(systemStatus){
// TODO get colors from parameters
	const liste_1 = ['APPR','INPRG']; 
	const liste_2 = ['CAN','CLOSE','COMP']; 
	const liste_3 = ['HISTEDIT','WAPPR','WMATL','WSCH'];
	if (liste_1.includes(systemStatus)) return '#0FC4A8' 
	else
	if (liste_2.includes(systemStatus)) return '#00B1F7'
	else
	if (liste_3.includes(systemStatus)) return '#0F9DC4'
	else 
	return '#21e6d7'
	
}